<h4> Cloud Optical Flow</h4>
Using OpenCV optical flow to determine cloud motion with a video/movie.


